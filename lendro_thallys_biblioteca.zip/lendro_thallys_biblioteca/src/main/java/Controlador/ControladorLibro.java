package Controlador;

import Modelo.Libro;
import Vista.PanelLibro;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class ControladorLibro {
    private PanelLibro vistaLibro;
    private List<Libro> listaLibros; // Lista para almacenar los libros

    public ControladorLibro(PanelLibro vistaLibro) {
        this.vistaLibro = vistaLibro;
        this.listaLibros = new ArrayList<>(); // Inicializar la lista de libros
        initControlador();
    }

    private void initControlador() {
        // Añadir oyentes a los botones
        vistaLibro.addCrearListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                crearLibro();
            }
        });

        vistaLibro.addEditarListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                editarLibro();
            }
        });

        vistaLibro.addBorrarListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                borrarLibro();
            }
        });

        vistaLibro.addBuscarListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buscarLibro();
            }
        });
    }

    private void crearLibro() {
        try {
            // Obtener los datos del formulario
            String titulo = vistaLibro.getTitulo();
            String autor = vistaLibro.getAutor();
            String ISBN = vistaLibro.getISBN();
            String genero = vistaLibro.getGenero();
            String editorial = vistaLibro.getEditorial();
            String edicion = vistaLibro.getEdicion();
            String fechaPublicacion = vistaLibro.getFechaPublicacion();
            boolean restricto = vistaLibro.isRestricto();
            boolean prestado = vistaLibro.isPrestado();

            // Crear el nuevo libro
            Libro libro = new Libro(titulo, autor, ISBN, genero, editorial, edicion, fechaPublicacion, restricto, prestado);
            listaLibros.add(libro); // Agregar el libro a la lista

            vistaLibro.setInformacion("Libro creado exitosamente:\n" + libro.toString());
        } catch (Exception ex) {
            vistaLibro.setInformacion("Error al crear el libro: " + ex.getMessage());
        }
    }

    private void editarLibro() {
        try {
            // Buscar un libro por su título
            String titulo = vistaLibro.getTitulo();
            Libro libro = buscarPorTitulo(titulo);

            if (libro != null) {
                // Actualizar los datos del libro
                libro.setAutor(vistaLibro.getAutor());
                libro.setISBN(vistaLibro.getISBN());
                libro.setGenero(vistaLibro.getGenero());
                libro.setEditorial(vistaLibro.getEditorial());
                libro.setEdicion(vistaLibro.getEdicion());
                libro.setFechaDePublicacion(vistaLibro.getFechaPublicacion());
                libro.setRestricto(vistaLibro.isRestricto());
                libro.setPrestado(vistaLibro.isPrestado());

                vistaLibro.setInformacion("Libro editado exitosamente:\n" + libro.toString());
            } else {
                vistaLibro.setInformacion("No se encontró un libro con el título: " + titulo);
            }
        } catch (Exception ex) {
            vistaLibro.setInformacion("Error al editar el libro: " + ex.getMessage());
        }
    }

    private void borrarLibro() {
        try {
            // Buscar un libro por su título
            String titulo = vistaLibro.getTitulo();
            Libro libro = buscarPorTitulo(titulo);

            if (libro != null) {
                listaLibros.remove(libro); // Eliminar el libro de la lista
                vistaLibro.setInformacion("Libro borrado exitosamente:\n" + libro.toString());
            } else {
                vistaLibro.setInformacion("No se encontró un libro con el título: " + titulo);
            }
        } catch (Exception ex) {
            vistaLibro.setInformacion("Error al borrar el libro: " + ex.getMessage());
        }
    }

    private void buscarLibro() {
        try {
            // Buscar un libro por su título
            String titulo = vistaLibro.getTitulo();
            Libro libro = buscarPorTitulo(titulo);

            if (libro != null) {
                vistaLibro.setInformacion("Libro encontrado:\n" + libro.toString());
            } else {
                vistaLibro.setInformacion("No se encontró un libro con el título: " + titulo);
            }
        } catch (Exception ex) {
            vistaLibro.setInformacion("Error al buscar el libro: " + ex.getMessage());
        }
    }

    private Libro buscarPorTitulo(String titulo) {
        for (Libro libro : listaLibros) {
            if (libro.getTitulo().equalsIgnoreCase(titulo)) {
                return libro;
            }
        }
        return null;
    }
}

package Controlador;

import Modelo.Prestamo;
import Vista.PanelPrestamo;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

public class ControladorPrestamo {

    private final PanelPrestamo panelPrestamo;
    private final List<Prestamo> prestamos; // Lista local para almacenar los préstamos

    public ControladorPrestamo(PanelPrestamo panelPrestamo) {
        this.panelPrestamo = panelPrestamo;
        this.prestamos = new ArrayList<>();
        initControlador();
    }

    private void initControlador() {
        // Asignar acciones a los botones
        panelPrestamo.addCrearListener(e -> crearPrestamo());
        panelPrestamo.addEditarListener(e -> editarPrestamo());
        panelPrestamo.addBorrarListener(e -> borrarPrestamo());
        panelPrestamo.addBuscarListener(e -> buscarPrestamo());
    }

    private void crearPrestamo() {
        try {
            int userId = Integer.parseInt(panelPrestamo.getIdUsuario());
            String[] libroIdsStr = panelPrestamo.getIdLibros().split(",");
            List<Integer> libroIds = new ArrayList<>();
            for (String id : libroIdsStr) {
                libroIds.add(Integer.parseInt(id.trim()));
            }

            LocalDate fechaPrestamo = parseFecha(panelPrestamo.getFechaPrestamo());
            String tipoUsuario = panelPrestamo.getTipoUsuario();

            // Crear un nuevo préstamo
            Prestamo prestamo = new Prestamo(userId, libroIds, java.sql.Date.valueOf(fechaPrestamo), null, tipoUsuario);
            prestamos.add(prestamo);

            panelPrestamo.setInformacion("Préstamo creado exitosamente:\n" + prestamo);
        } catch (NumberFormatException ex) {
            panelPrestamo.setInformacion("Error: ID del usuario o libros no válidos.");
        } catch (DateTimeParseException ex) {
            panelPrestamo.setInformacion("Error: Formato de fecha inválido.");
        } catch (Exception ex) {
            panelPrestamo.setInformacion("Error inesperado: " + ex.getMessage());
        }
    }

    private void editarPrestamo() {
        try {
            int prestamoId = Integer.parseInt(panelPrestamo.getIdPrestamo());
            Prestamo prestamo = buscarPrestamoPorId(prestamoId);

            if (prestamo == null) {
                panelPrestamo.setInformacion("Préstamo no encontrado.");
                return;
            }

            String nuevaFechaDevolucion = panelPrestamo.getFechaDevolucion();
            if (!nuevaFechaDevolucion.isEmpty()) {
                LocalDate fechaDevolucion = parseFecha(nuevaFechaDevolucion);
                prestamo.setFechaDeDevolucion(java.sql.Date.valueOf(fechaDevolucion));
                panelPrestamo.setInformacion("Fecha de devolución actualizada:\n" + prestamo);
            } else {
                panelPrestamo.setInformacion("No se proporcionó una nueva fecha de devolución.");
            }
        } catch (NumberFormatException ex) {
            panelPrestamo.setInformacion("Error: ID del préstamo no válido.");
        } catch (DateTimeParseException ex) {
            panelPrestamo.setInformacion("Error: Formato de fecha inválido.");
        } catch (Exception ex) {
            panelPrestamo.setInformacion("Error inesperado: " + ex.getMessage());
        }
    }

    private void borrarPrestamo() {
        try {
            int prestamoId = Integer.parseInt(panelPrestamo.getIdPrestamo());
            Prestamo prestamo = buscarPrestamoPorId(prestamoId);

            if (prestamo == null) {
                panelPrestamo.setInformacion("Préstamo no encontrado.");
                return;
            }

            prestamos.remove(prestamo);
            panelPrestamo.setInformacion("Préstamo eliminado:\n" + prestamo);
        } catch (NumberFormatException ex) {
            panelPrestamo.setInformacion("Error: ID del préstamo no válido.");
        } catch (Exception ex) {
            panelPrestamo.setInformacion("Error inesperado: " + ex.getMessage());
        }
    }

    private void buscarPrestamo() {
        try {
            int prestamoId = Integer.parseInt(panelPrestamo.getIdPrestamo());
            Prestamo prestamo = buscarPrestamoPorId(prestamoId);

            if (prestamo != null) {
                panelPrestamo.setInformacion("Préstamo encontrado:\n" + prestamo);
            } else {
                panelPrestamo.setInformacion("Préstamo no encontrado.");
            }
        } catch (NumberFormatException ex) {
            panelPrestamo.setInformacion("Error: ID del préstamo no válido.");
        } catch (Exception ex) {
            panelPrestamo.setInformacion("Error inesperado: " + ex.getMessage());
        }
    }

    private Prestamo buscarPrestamoPorId(int id) {
        for (Prestamo prestamo : prestamos) {
            if (prestamo.getPrestamoId() == id) {
                return prestamo;
            }
        }
        return null;
    }

    private LocalDate parseFecha(String fecha) throws DateTimeParseException {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        return LocalDate.parse(fecha, formatter);
    }
}

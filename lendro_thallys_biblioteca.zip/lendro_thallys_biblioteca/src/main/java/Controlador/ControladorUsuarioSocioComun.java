package Controlador;

import Modelo.UsuarioSocioComun;
import Vista.VistaUsuarioSocioComun;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class ControladorUsuarioSocioComun {

    private VistaUsuarioSocioComun vista;
    private List<UsuarioSocioComun> listaUsuarios;

    public ControladorUsuarioSocioComun(VistaUsuarioSocioComun vista) {
        this.vista = vista;
        this.listaUsuarios = new ArrayList<>();
        initControlador();
    }

    private void initControlador() {
        vista.getBotonCrear().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                crearUsuario();
            }
        });

        vista.getBotonEditar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                editarUsuario();
            }
        });

        vista.getBotonBorrar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                borrarUsuario();
            }
        });

        vista.getBotonBuscar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buscarUsuario();
            }
        });
    }

    private void crearUsuario() {
        try {
            String apellido = vista.getCampoApellido().getText();
            String nombre = vista.getCampoNombre().getText();
            String password = vista.getCampoPassword().getText();
            String telefono = vista.getCampoTelefono().getText();
            String email = vista.getCampoEmail().getText();
            String direccion = vista.getCampoDireccion().getText();

            UsuarioSocioComun nuevoUsuario = new UsuarioSocioComun(apellido, nombre, password, telefono, email, direccion);
            listaUsuarios.add(nuevoUsuario);

            JOptionPane.showMessageDialog(vista, "Usuario creado exitosamente.");
            limpiarCampos();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(vista, "Error al crear el usuario: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void editarUsuario() {
        try {
            int id = Integer.parseInt(vista.getCampoId().getText());

            UsuarioSocioComun usuario = buscarUsuarioPorId(id);
            if (usuario != null) {
                usuario.setApellido(vista.getCampoApellido().getText());
                usuario.setNombre(vista.getCampoNombre().getText());
                usuario.setPassword(vista.getCampoPassword().getText());
                usuario.setNumeroDeTelefono(vista.getCampoTelefono().getText());
                usuario.setEmail(vista.getCampoEmail().getText());
                usuario.setDireccion(vista.getCampoDireccion().getText());

                JOptionPane.showMessageDialog(vista, "Usuario editado exitosamente.");
                limpiarCampos();
            } else {
                JOptionPane.showMessageDialog(vista, "Usuario no encontrado.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(vista, "ID no válido.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void borrarUsuario() {
        try {
            int id = Integer.parseInt(vista.getCampoId().getText());

            UsuarioSocioComun usuario = buscarUsuarioPorId(id);
            if (usuario != null) {
                listaUsuarios.remove(usuario);
                JOptionPane.showMessageDialog(vista, "Usuario eliminado exitosamente.");
                limpiarCampos();
            } else {
                JOptionPane.showMessageDialog(vista, "Usuario no encontrado.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(vista, "ID no válido.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void buscarUsuario() {
        try {
            int id = Integer.parseInt(vista.getCampoId().getText());

            UsuarioSocioComun usuario = buscarUsuarioPorId(id);
            if (usuario != null) {
                vista.getCampoApellido().setText(usuario.getApellido());
                vista.getCampoNombre().setText(usuario.getNombre());
                vista.getCampoPassword().setText(usuario.getPassword());
                vista.getCampoTelefono().setText(usuario.getNumeroDeTelefono());
                vista.getCampoEmail().setText(usuario.getEmail());
                vista.getCampoDireccion().setText(usuario.getDireccion());
            } else {
                JOptionPane.showMessageDialog(vista, "Usuario no encontrado.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(vista, "ID no válido.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private UsuarioSocioComun buscarUsuarioPorId(int id) {
        for (UsuarioSocioComun usuario : listaUsuarios) {
            if (usuario.getUserId() == id) {
                return usuario;
            }
        }
        return null;
    }

    private void limpiarCampos() {
        vista.getCampoId().setText("");
        vista.getCampoApellido().setText("");
        vista.getCampoNombre().setText("");
        vista.getCampoPassword().setText("");
        vista.getCampoTelefono().setText("");
        vista.getCampoEmail().setText("");
        vista.getCampoDireccion().setText("");
    }
}


package Controlador;

import Modelo.UsuarioSocioPremium;
import Vista.VistaUsuarioSocioPremium;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class ControladorUsuarioSocioPremium {

    private VistaUsuarioSocioPremium vista;
    private List<UsuarioSocioPremium> listaUsuarios;

    public ControladorUsuarioSocioPremium(VistaUsuarioSocioPremium vista) {
        this.vista = vista;
        this.listaUsuarios = new ArrayList<>();
        initControlador();
    }

    private void initControlador() {
        // Asignar acciones a los botones
        vista.addCrearListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                crearUsuario();
            }
        });

        vista.addEditarListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                editarUsuario();
            }
        });

        vista.addBorrarListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                borrarUsuario();
            }
        });

        vista.addBuscarListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buscarUsuario();
            }
        });
    }

    private void crearUsuario() {
        try {
            String apellido = vista.getCampoApellido();
            String nombre = vista.getCampoNombre();
            String telefono = vista.getCampoTelefono();
            String email = vista.getCampoEmail();
            String direccion = vista.getCampoDireccion();
            String fechaInicio = vista.getCampoFechaInicio();
            String fechaFin = vista.getCampoFechaFin();

            // Crear el usuario Socio Premium
            UsuarioSocioPremium nuevoUsuario = new UsuarioSocioPremium(apellido, nombre, telefono, email, direccion, fechaInicio, fechaFin);
            listaUsuarios.add(nuevoUsuario);

            vista.setInformacion("Usuario Socio Premium creado exitosamente:\n" + nuevoUsuario);
            limpiarCampos();
        } catch (Exception ex) {
            vista.setInformacion("Error al crear el usuario: " + ex.getMessage());
        }
    }

    private void editarUsuario() {
        try {
            String idTexto = vista.getCampoId();
            if (idTexto.isEmpty()) {
                vista.setInformacion("El ID no puede estar vacío.");
                return;
            }

            int id = Integer.parseInt(idTexto);
            UsuarioSocioPremium usuario = buscarUsuarioPorId(id);

            if (usuario != null) {
                // Actualizar los datos del usuario
                usuario.setApellido(vista.getCampoApellido());
                usuario.setNombre(vista.getCampoNombre());
                usuario.setNumeroDeTelefono(vista.getCampoTelefono());
                usuario.setEmail(vista.getCampoEmail());
                usuario.setDireccion(vista.getCampoDireccion());
                usuario.setFechaInicio(vista.getCampoFechaInicio());
                usuario.setFechaFin(vista.getCampoFechaFin());

                vista.setInformacion("Usuario Socio Premium editado exitosamente:\n" + usuario);
            } else {
                vista.setInformacion("Usuario no encontrado.");
            }
        } catch (NumberFormatException ex) {
            vista.setInformacion("El ID ingresado no es válido.");
        } catch (Exception ex) {
            vista.setInformacion("Error al editar el usuario: " + ex.getMessage());
        }
    }

    private void borrarUsuario() {
        try {
            String idTexto = vista.getCampoId();
            if (idTexto.isEmpty()) {
                vista.setInformacion("El ID no puede estar vacío.");
                return;
            }

            int id = Integer.parseInt(idTexto);
            UsuarioSocioPremium usuario = buscarUsuarioPorId(id);

            if (usuario != null) {
                listaUsuarios.remove(usuario);
                vista.setInformacion("Usuario Socio Premium eliminado exitosamente:\n" + usuario);
                limpiarCampos();
            } else {
                vista.setInformacion("Usuario no encontrado.");
            }
        } catch (NumberFormatException ex) {
            vista.setInformacion("El ID ingresado no es válido.");
        } catch (Exception ex) {
            vista.setInformacion("Error al borrar el usuario: " + ex.getMessage());
        }
    }

    private void buscarUsuario() {
        try {
            String idTexto = vista.getCampoId();
            if (idTexto.isEmpty()) {
                vista.setInformacion("El ID no puede estar vacío.");
                return;
            }

            int id = Integer.parseInt(idTexto);
            UsuarioSocioPremium usuario = buscarUsuarioPorId(id);

            if (usuario != null) {
                // Mostrar los datos del usuario en la vista
                vista.setInformacion("Usuario encontrado:\n" + usuario);
            } else {
                vista.setInformacion("Usuario no encontrado.");
            }
        } catch (NumberFormatException ex) {
            vista.setInformacion("El ID ingresado no es válido.");
        } catch (Exception ex) {
            vista.setInformacion("Error al buscar el usuario: " + ex.getMessage());
        }
    }

    private UsuarioSocioPremium buscarUsuarioPorId(int id) {
        for (UsuarioSocioPremium usuario : listaUsuarios) {
            if (usuario.getUserId() == id) {
                return usuario;
            }
        }
        return null;
    }

    private void limpiarCampos() {
        vista.getCampoId().setText("");
        vista.getCampoApellido().setText("");
        vista.getCampoNombre().setText("");
        vista.getCampoTelefono().setText("");
        vista.getCampoEmail().setText("");
        vista.getCampoDireccion().setText("");
        vista.getCampoFechaInicio().setText("");
        vista.getCampoFechaFin().setText("");
    }
}

package Modelo;

import java.io.Serializable;
 // Implementar Serializable para guardar en XML
public class Libro implements Serializable{ // Implementar Serializable para guardar en XML
    // Atributos
    private static int contadorLibros = 0; // Contador estático para generar IDs únicos
    private int libroId;                  // ID único para cada libro
    private String titulo;
    private String autor;
    private String ISBN;
    private String genero;
    private String editorial;
    private String edicion;
    private String fechaDePublicacion;
    private boolean restricto;
    private boolean prestado;

    // Constructor
    public Libro(String titulo, String autor, String ISBN, String genero, String editorial,
                 String edicion, String fechaDePublicacion, boolean restricto, boolean prestado) {
        this.libroId = ++contadorLibros; // Asigna un ID único y lo incrementa
        this.titulo = titulo;
        this.autor = autor;
        this.ISBN = ISBN;
        this.genero = genero;
        this.editorial = editorial;
        this.edicion = edicion;
        this.fechaDePublicacion = fechaDePublicacion;
        this.restricto = restricto;
        this.prestado = prestado;
    }

    // Getters y Setters
    public int getLibroId() {
        return libroId;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getISBN() {
        return ISBN;
    }

    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getEditorial() {
        return editorial;
    }

    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }

    public String getEdicion() {
        return edicion;
    }

    public void setEdicion(String edicion) {
        this.edicion = edicion;
    }

    public String getFechaDePublicacion() {
        return fechaDePublicacion;
    }

    public void setFechaDePublicacion(String fechaDePublicacion) {
        this.fechaDePublicacion = fechaDePublicacion;
    }

    public boolean isRestricto() {
        return restricto;
    }

    public void setRestricto(boolean restricto) {
        this.restricto = restricto;
    }

    public boolean isPrestado() {
        return prestado;
    }

    public void setPrestado(boolean prestado) {
        this.prestado = prestado;
    }

    // Método para mostrar la información del libro
    @Override
    public String toString() {
        return "Libro ID: " + libroId + 
               "\nTítulo: " + titulo + 
               "\nAutor: " + autor + 
               "\nISBN: " + ISBN + 
               "\nGénero: " + genero + 
               "\nEditorial: " + editorial + 
               "\nEdición: " + edicion + 
               "\nFecha de Publicación: " + fechaDePublicacion + 
               "\nRestricto: " + restricto + 
               "\nPrestado: " + prestado;
    }
}

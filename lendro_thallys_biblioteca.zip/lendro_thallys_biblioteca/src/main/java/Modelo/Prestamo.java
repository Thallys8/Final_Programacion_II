package Modelo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Calendar;

public class Prestamo implements Serializable { // Implementar Serializable para guardar en XML
    private static final long serialVersionUID = 1L; // Para garantizar la compatibilidad entre diferentes versiones de clases
    
    private static int contadorPrestamos = 0;  // Contador estático para el auto-incremento del ID
    private int prestamoId;  // ID único para cada préstamo
    private int userId;      // ID del usuario que realiza el préstamo
    private List<Integer> libroIds;  // Lista de IDs de los libros prestados
    private Date fechaDePrestamo;
    private Date fechaLimite;
    private Date fechaDeDevolucion;
    private long diasDeRetraso;

    // Constructor
    public Prestamo(int userId, List<Integer> libroIds, Date fechaDePrestamo, Date fechaDeDevolucion, String tipoUsuario) {
        this.prestamoId = ++contadorPrestamos;  // Asigna un ID único e incrementa el contador
        this.userId = userId;
        this.libroIds = libroIds;
        this.fechaDePrestamo = fechaDePrestamo;
        this.fechaDeDevolucion = fechaDeDevolucion;
        this.fechaLimite = calcularFechaLimite(fechaDePrestamo, tipoUsuario);  // Calcular la fecha límite según el tipo de usuario
        this.diasDeRetraso = calcularDiasDeRetraso();  // Calcular los días de retraso
    }

    // Método para calcular la fecha límite dependiendo del tipo de usuario
    private Date calcularFechaLimite(Date fechaDePrestamo, String tipoUsuario) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(fechaDePrestamo);  // Establecer la fecha de préstamo como base

        if (tipoUsuario.equals("SocioComun")) {
            calendar.add(Calendar.DAY_OF_YEAR, 15);  // Para SocioComún, añadir 15 días
        } else if (tipoUsuario.equals("SocioPremium")) {
            calendar.add(Calendar.DAY_OF_YEAR, 30);  // Para SocioPremium, añadir 30 días
        }

        return calendar.getTime();  // Retorna la fecha límite calculada
    }

    // Método para calcular los días de retraso
    private long calcularDiasDeRetraso() {
        if (fechaDeDevolucion != null && fechaDeDevolucion.after(fechaLimite)) {
            return (fechaDeDevolucion.getTime() - fechaLimite.getTime()) / (1000 * 60 * 60 * 24);  // Calcula días de retraso
        }
        return 0;  // Si no hay retraso, devuelve 0
    }

    // Getter para los días de retraso
    public long getDiasDeRetraso() {
        return diasDeRetraso;
    }

    // Getter para el ID del préstamo
    public int getPrestamoId() {
        return prestamoId;
    }

    // Getter para el ID del usuario
    public int getUserId() {
        return userId;
    }

    // Getter para la lista de IDs de libros
    public List<Integer> getLibroIds() {
        return libroIds;
    }

    // Getter para la fecha de préstamo
    public Date getFechaDePrestamo() {
        return fechaDePrestamo;
    }

    // Getter para la fecha límite
    public Date getFechaLimite() {
        return fechaLimite;
    }

    // Getter para la fecha de devolución
    public Date getFechaDeDevolucion() {
        return fechaDeDevolucion;
    }

    // Método para mostrar la información del préstamo (opcional, pero útil para depuración)
    @Override
    public String toString() {
        return "Prestamo [prestamoId=" + prestamoId + ", userId=" + userId + ", libroIds=" + libroIds
                + ", fechaDePrestamo=" + fechaDePrestamo + ", fechaLimite=" + fechaLimite
                + ", fechaDeDevolucion=" + fechaDeDevolucion + ", diasDeRetraso=" + diasDeRetraso + "]";
    }

    public void setFechaDeDevolucion(java.sql.Date valueOf) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

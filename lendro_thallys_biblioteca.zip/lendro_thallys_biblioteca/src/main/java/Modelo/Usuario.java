package Modelo;

import java.io.Serializable;
import java.util.List;

public class Usuario implements Serializable { // Implementar Serializable para guardar en XML
    private static final long serialVersionUID = 1L; // Para garantizar la compatibilidad entre diferentes versiones de clases

    // Contador estático para asignar IDs únicos
    private static int contadorUsuarios = 0;

    private int userId;
    private String apellido;
    private String nombre;
    private String password;
    private String numeroDeTelefono;
    private String email;
    private String direccion;
    
    // Total de días de retraso de este usuario en todos sus préstamos
    private int totalDiasDeRetraso;

    // Lista de préstamos de este usuario
    private List<Prestamo> prestamos;

    // Constructor
    public Usuario(String apellido, String nombre, String password, String numeroDeTelefono, 
                   String email, String direccion) {
        this.userId = ++contadorUsuarios;  // Asignación automática de ID único
        this.apellido = apellido;
        this.nombre = nombre;
        this.password = password;
        this.numeroDeTelefono = numeroDeTelefono;
        this.email = email;
        this.direccion = direccion;
        this.totalDiasDeRetraso = 0;  // Inicializa los días de retraso en 0
    }

    // Método para agregar un préstamo al usuario
    public void agregarPrestamo(Prestamo prestamo) {
        this.prestamos.add(prestamo);
        // Actualizar el total de días de retraso después de agregar un nuevo préstamo
        actualizarTotalDiasDeRetraso();
    }

    // Método para actualizar el total de días de retraso sumando los días de todos los préstamos
    private void actualizarTotalDiasDeRetraso() {
        this.totalDiasDeRetraso = 0;  // Reiniciar el total antes de recalcular
        for (Prestamo prestamo : prestamos) {
            this.totalDiasDeRetraso += prestamo.getDiasDeRetraso();  // Sumar los días de retraso de cada préstamo
        }
    }

    // Método para obtener el total de días de retraso
    public int getTotalDiasDeRetraso() {
        return totalDiasDeRetraso;
    }

    // Getters y Setters
    public int getUserId() {
        return userId;
    }

    public String getApellido() {
        return apellido;
    }

    public String getNombre() {
        return nombre;
    }

    public String getPassword() {
        return password;
    }

    public String getNumeroDeTelefono() {
        return numeroDeTelefono;
    }

    public String getEmail() {
        return email;
    }

    public String getDireccion() {
        return direccion;
    }

    // Getter para la lista de préstamos
    public List<Prestamo> getPrestamos() {
        return prestamos;
    }

    // Método toString para mostrar la información del usuario
    @Override
    public String toString() {
        return "Usuario [userId=" + userId + ", apellido=" + apellido + ", nombre=" + nombre 
                + ", totalDiasDeRetraso=" + totalDiasDeRetraso + "]";
    }
}

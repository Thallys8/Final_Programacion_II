package Modelo;

import java.io.Serializable;

public class UsuarioBibliotecario extends Usuario implements Serializable{ // Implementar Serializable para guardar en XML
    // Constructor
    public UsuarioBibliotecario(String apellido, String nombre, String password, String numeroDeTelefono, 
                         String email, String direccion) {
        super(apellido, nombre, password, numeroDeTelefono, email, direccion);
    }

    // Método específico para administrar
    public void gestionarBiblioteca() {
        System.out.println("El bibliotecario " + getNombre() + " está gestionando la biblioteca.");
    }

    @Override
    public String toString() {
        return "Bibliotecario: " + super.toString();
    }
}
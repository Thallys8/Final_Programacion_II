package Modelo;

import java.io.Serializable;

public class UsuarioSocioComun extends Usuario implements Serializable{ // Implementar Serializable para guardar en XML
    private static final int LIMITE_LIBROS = 3;
    private static final int DIAS_PRESTAMO = 15; // Período de préstamo en días

    // Constructor
    public UsuarioSocioComun(String apellido, String nombre, String password, String numeroDeTelefono, 
                              String email, String direccion) {
        super(apellido, nombre, password, numeroDeTelefono, email, direccion);
    }

    // Método para verificar si el socio puede llevar un libro restrictivo
    public boolean puedeLlevarRestrictivo() {
        return false;
    }

    // Método para obtener el límite de libros
    public int getLimiteLibros() {
        return LIMITE_LIBROS;
    }

    // Método para obtener el período de préstamo
    public int getDiasPrestamo() {
        return DIAS_PRESTAMO;
    }

    @Override
    public String toString() {
        return "Usuario Socio Común: " + super.toString() + 
               "\nLímite de libros: " + LIMITE_LIBROS + 
               "\nPuede llevar libros restrictivos: No" + 
               "\nDías de préstamo: " + DIAS_PRESTAMO;
    }
}


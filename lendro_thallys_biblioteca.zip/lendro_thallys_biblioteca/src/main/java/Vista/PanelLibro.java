package Vista;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class PanelLibro extends JPanel {
    // Componentes de la interfaz
    private JTextField campoTitulo, campoAutor, campoISBN, campoGenero, campoEditorial, campoEdicion, campoFechaPublicacion;
    private JCheckBox checkRestricto, checkPrestado;
    private JButton botonCrear, botonEditar, botonBorrar, botonBuscar;
    private JTextArea areaInformacion;

    public PanelLibro() {
        setLayout(new BorderLayout());
        initFormulario();
        initBotones();
    }

    private void initFormulario() {
        JPanel panelFormulario = new JPanel(new GridLayout(8, 2));

        panelFormulario.add(new JLabel("Título:"));
        campoTitulo = new JTextField();
        panelFormulario.add(campoTitulo);

        panelFormulario.add(new JLabel("Autor:"));
        campoAutor = new JTextField();
        panelFormulario.add(campoAutor);

        panelFormulario.add(new JLabel("ISBN:"));
        campoISBN = new JTextField();
        panelFormulario.add(campoISBN);

        panelFormulario.add(new JLabel("Género:"));
        campoGenero = new JTextField();
        panelFormulario.add(campoGenero);

        panelFormulario.add(new JLabel("Editorial:"));
        campoEditorial = new JTextField();
        panelFormulario.add(campoEditorial);

        panelFormulario.add(new JLabel("Edición:"));
        campoEdicion = new JTextField();
        panelFormulario.add(campoEdicion);

        panelFormulario.add(new JLabel("Fecha Publicación:"));
        campoFechaPublicacion = new JTextField();
        panelFormulario.add(campoFechaPublicacion);

        checkRestricto = new JCheckBox("Restricto");
        panelFormulario.add(checkRestricto);

        checkPrestado = new JCheckBox("Prestado");
        panelFormulario.add(checkPrestado);

        add(panelFormulario, BorderLayout.NORTH);
    }

    private void initBotones() {
        JPanel panelBotones = new JPanel();
        botonCrear = new JButton("Crear");
        botonEditar = new JButton("Editar");
        botonBorrar = new JButton("Borrar");
        botonBuscar = new JButton("Buscar");

        panelBotones.add(botonCrear);
        panelBotones.add(botonEditar);
        panelBotones.add(botonBorrar);
        panelBotones.add(botonBuscar);

        add(panelBotones, BorderLayout.SOUTH);

        areaInformacion = new JTextArea(10, 30);
        areaInformacion.setEditable(false);
        add(new JScrollPane(areaInformacion), BorderLayout.CENTER);
    }

    // Métodos para acceder a los datos del formulario
    public String getTitulo() { return campoTitulo.getText(); }
    public String getAutor() { return campoAutor.getText(); }
    public String getISBN() { return campoISBN.getText(); }
    public String getGenero() { return campoGenero.getText(); }
    public String getEditorial() { return campoEditorial.getText(); }
    public String getEdicion() { return campoEdicion.getText(); }
    public String getFechaPublicacion() { return campoFechaPublicacion.getText(); }
    public boolean isRestricto() { return checkRestricto.isSelected(); }
    public boolean isPrestado() { return checkPrestado.isSelected(); }

    public void setInformacion(String info) {
        areaInformacion.setText(info);
    }

    // Métodos para añadir oyentes a los botones
    public void addCrearListener(ActionListener listener) {
        botonCrear.addActionListener(listener);
    }

    public void addEditarListener(ActionListener listener) {
        botonEditar.addActionListener(listener);
    }

    public void addBorrarListener(ActionListener listener) {
        botonBorrar.addActionListener(listener);
    }

    public void addBuscarListener(ActionListener listener) {
        botonBuscar.addActionListener(listener);
    }
}

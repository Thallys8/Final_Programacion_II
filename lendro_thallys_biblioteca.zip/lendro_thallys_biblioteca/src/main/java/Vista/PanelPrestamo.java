package Vista;

import javax.swing.*;
import java.awt.*;

public class PanelPrestamo extends JPanel {
    // Componentes para la entrada de datos
    private JTextField campoIdPrestamo;
    private JTextField campoIdUsuario;
    private JTextField campoIdLibros;
    private JTextField campoFechaPrestamo;
    private JTextField campoFechaDevolucion;
    private JTextField campoTipoUsuario;

    // Botones de acción
    private JButton botonCrear;
    private JButton botonEditar;
    private JButton botonBorrar;
    private JButton botonBuscar;

    // Área de texto para mostrar información
    private JTextArea areaInformacion;

    public PanelPrestamo() {
        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        // Panel para los campos de formulario
        JPanel panelFormulario = new JPanel(new GridLayout(6, 2, 5, 5));
        panelFormulario.setBorder(BorderFactory.createTitledBorder("Datos del Préstamo"));

        panelFormulario.add(new JLabel("ID del Préstamo:"));
        campoIdPrestamo = new JTextField();
        panelFormulario.add(campoIdPrestamo);

        panelFormulario.add(new JLabel("ID del Usuario:"));
        campoIdUsuario = new JTextField();
        panelFormulario.add(campoIdUsuario);

        panelFormulario.add(new JLabel("IDs de Libros (separados por comas):"));
        campoIdLibros = new JTextField();
        panelFormulario.add(campoIdLibros);

        panelFormulario.add(new JLabel("Fecha de Préstamo (YYYY-MM-DD):"));
        campoFechaPrestamo = new JTextField();
        panelFormulario.add(campoFechaPrestamo);

        panelFormulario.add(new JLabel("Fecha de Devolución (YYYY-MM-DD):"));
        campoFechaDevolucion = new JTextField();
        panelFormulario.add(campoFechaDevolucion);

        panelFormulario.add(new JLabel("Tipo de Usuario (SocioComun/SocioPremium):"));
        campoTipoUsuario = new JTextField();
        panelFormulario.add(campoTipoUsuario);

        // Panel para los botones de acción
        JPanel panelBotones = new JPanel(new FlowLayout());
        botonCrear = new JButton("Crear Préstamo");
        botonEditar = new JButton("Editar Préstamo");
        botonBorrar = new JButton("Borrar Préstamo");
        botonBuscar = new JButton("Buscar Préstamo");

        panelBotones.add(botonCrear);
        panelBotones.add(botonEditar);
        panelBotones.add(botonBorrar);
        panelBotones.add(botonBuscar);

        // Área de texto para mostrar información
        areaInformacion = new JTextArea(10, 30);
        areaInformacion.setEditable(false);
        JScrollPane scrollArea = new JScrollPane(areaInformacion);
        scrollArea.setBorder(BorderFactory.createTitledBorder("Información"));

        // Añadir componentes al panel principal
        add(panelFormulario, BorderLayout.NORTH);
        add(panelBotones, BorderLayout.CENTER);
        add(scrollArea, BorderLayout.SOUTH);
    }

    // Métodos para obtener los valores de los campos
    public String getIdPrestamo() {
        return campoIdPrestamo.getText();
    }

    public String getIdUsuario() {
        return campoIdUsuario.getText();
    }

    public String getIdLibros() {
        return campoIdLibros.getText();
    }

    public String getFechaPrestamo() {
        return campoFechaPrestamo.getText();
    }

    public String getFechaDevolucion() {
        return campoFechaDevolucion.getText();
    }

    public String getTipoUsuario() {
        return campoTipoUsuario.getText();
    }

    // Métodos para establecer la información en el área de texto
    public void setInformacion(String info) {
        areaInformacion.setText(info);
    }

    // Métodos para añadir oyentes a los botones
    public void addCrearListener(java.awt.event.ActionListener listener) {
        botonCrear.addActionListener(listener);
    }

    public void addEditarListener(java.awt.event.ActionListener listener) {
        botonEditar.addActionListener(listener);
    }

    public void addBorrarListener(java.awt.event.ActionListener listener) {
        botonBorrar.addActionListener(listener);
    }

    public void addBuscarListener(java.awt.event.ActionListener listener) {
        botonBuscar.addActionListener(listener);
    }
}

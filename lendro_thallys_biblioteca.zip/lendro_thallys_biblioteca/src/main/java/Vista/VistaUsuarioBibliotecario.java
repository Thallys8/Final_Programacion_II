package Vista;

import Modelo.UsuarioBibliotecario;

import javax.swing.*;
import java.awt.*;

public class VistaUsuarioBibliotecario extends JPanel {

    // Componentes de la vista
    private JTextField campoId;
    private JTextField campoApellido;
    private JTextField campoNombre;
    private JTextField campoPassword;
    private JTextField campoTelefono;
    private JTextField campoEmail;
    private JTextField campoDireccion;
    private JTextArea areaInformacion;
    private JButton botonCrear;
    private JButton botonEditar;
    private JButton botonBorrar;
    private JButton botonBuscar;

    public VistaUsuarioBibliotecario() {
        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        // Panel superior para el formulario
        JPanel panelFormulario = new JPanel(new GridLayout(7, 2));

        panelFormulario.add(new JLabel("ID (solo para editar/borrar/buscar):"));
        campoId = new JTextField();
        panelFormulario.add(campoId);

        panelFormulario.add(new JLabel("Apellido:"));
        campoApellido = new JTextField();
        panelFormulario.add(campoApellido);

        panelFormulario.add(new JLabel("Nombre:"));
        campoNombre = new JTextField();
        panelFormulario.add(campoNombre);

        panelFormulario.add(new JLabel("Password:"));
        campoPassword = new JTextField();
        panelFormulario.add(campoPassword);

        panelFormulario.add(new JLabel("Teléfono:"));
        campoTelefono = new JTextField();
        panelFormulario.add(campoTelefono);

        panelFormulario.add(new JLabel("Email:"));
        campoEmail = new JTextField();
        panelFormulario.add(campoEmail);

        panelFormulario.add(new JLabel("Dirección:"));
        campoDireccion = new JTextField();
        panelFormulario.add(campoDireccion);

        // Área de texto para mostrar información
        areaInformacion = new JTextArea(10, 30);
        areaInformacion.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(areaInformacion);

        // Panel inferior para los botones
        JPanel panelBotones = new JPanel();
        botonCrear = new JButton("Crear");
        botonEditar = new JButton("Editar");
        botonBorrar = new JButton("Borrar");
        botonBuscar = new JButton("Buscar");

        panelBotones.add(botonCrear);
        panelBotones.add(botonEditar);
        panelBotones.add(botonBorrar);
        panelBotones.add(botonBuscar);

        // Agregar componentes al panel principal
        add(panelFormulario, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(panelBotones, BorderLayout.SOUTH);
    }

    // Getters para los campos y botones
    public JTextField getCampoId() {
        return campoId;
    }

    public JTextField getCampoApellido() {
        return campoApellido;
    }

    public JTextField getCampoNombre() {
        return campoNombre;
    }

    public JTextField getCampoPassword() {
        return campoPassword;
    }

    public JTextField getCampoTelefono() {
        return campoTelefono;
    }

    public JTextField getCampoEmail() {
        return campoEmail;
    }

    public JTextField getCampoDireccion() {
        return campoDireccion;
    }

    public JTextArea getAreaInformacion() {
        return areaInformacion;
    }

    public JButton getBotonCrear() {
        return botonCrear;
    }

    public JButton getBotonEditar() {
        return botonEditar;
    }

    public JButton getBotonBorrar() {
        return botonBorrar;
    }

    public JButton getBotonBuscar() {
        return botonBuscar;
    }
}


package Vista;

import Modelo.UsuarioSocioComun;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VistaUsuarioSocioComun extends JPanel {

    private JTextField campoApellido;
    private JTextField campoNombre;
    private JTextField campoPassword;
    private JTextField campoTelefono;
    private JTextField campoEmail;
    private JTextField campoDireccion;
    private JTextArea areaInformacion;
    private JButton botonCrear;
    private JButton botonEditar;
    private JButton botonBorrar;

    public VistaUsuarioSocioComun() {
        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        // Panel para el formulario
        JPanel panelFormulario = new JPanel();
        panelFormulario.setLayout(new GridLayout(6, 2));

        panelFormulario.add(new JLabel("Apellido:"));
        campoApellido = new JTextField();
        panelFormulario.add(campoApellido);

        panelFormulario.add(new JLabel("Nombre:"));
        campoNombre = new JTextField();
        panelFormulario.add(campoNombre);

        panelFormulario.add(new JLabel("Password:"));
        campoPassword = new JTextField();
        panelFormulario.add(campoPassword);

        panelFormulario.add(new JLabel("Teléfono:"));
        campoTelefono = new JTextField();
        panelFormulario.add(campoTelefono);

        panelFormulario.add(new JLabel("Email:"));
        campoEmail = new JTextField();
        panelFormulario.add(campoEmail);

        panelFormulario.add(new JLabel("Dirección:"));
        campoDireccion = new JTextField();
        panelFormulario.add(campoDireccion);

        // Panel para los botones
        JPanel panelBotones = new JPanel();
        botonCrear = new JButton("Crear Usuario");
        botonEditar = new JButton("Editar Usuario");
        botonBorrar = new JButton("Borrar Usuario");
        panelBotones.add(botonCrear);
        panelBotones.add(botonEditar);
        panelBotones.add(botonBorrar);

        // Área de información
        areaInformacion = new JTextArea(10, 30);
        areaInformacion.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(areaInformacion);

        // Añadir componentes al panel principal
        add(panelFormulario, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(panelBotones, BorderLayout.SOUTH);

        // Eventos de los botones
        botonCrear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                crearUsuario();
            }
        });

        botonEditar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                editarUsuario();
            }
        });

        botonBorrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                borrarUsuario();
            }
        });
    }

    private void crearUsuario() {
        String apellido = campoApellido.getText();
        String nombre = campoNombre.getText();
        String password = campoPassword.getText();
        String telefono = campoTelefono.getText();
        String email = campoEmail.getText();
        String direccion = campoDireccion.getText();

        UsuarioSocioComun usuario = new UsuarioSocioComun(apellido, nombre, password, telefono, email, direccion);
        areaInformacion.setText("Usuario creado:\n" + usuario);
    }

    private void editarUsuario() {
        areaInformacion.setText("Funcionalidad de editar usuario aún no implementada.");
    }

    private void borrarUsuario() {
        areaInformacion.setText("Funcionalidad de borrar usuario aún no implementada.");
    }
}

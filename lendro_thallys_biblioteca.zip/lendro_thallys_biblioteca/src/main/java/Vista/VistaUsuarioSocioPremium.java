package Vista;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class VistaUsuarioSocioPremium extends JPanel {
    private JTextField campoId;
    private JTextField campoApellido;
    private JTextField campoNombre;
    private JTextField campoTelefono;
    private JTextField campoEmail;
    private JTextField campoDireccion;
    private JTextField campoFechaInicio;
    private JTextField campoFechaFin;
    private JButton botonCrear;
    private JButton botonEditar;
    private JButton botonBorrar;
    private JButton botonBuscar;
    private JTextArea areaInformacion;

    public VistaUsuarioSocioPremium() {
        setLayout(new BorderLayout());
        
        // Panel para los campos de texto
        JPanel panelCampos = new JPanel();
        panelCampos.setLayout(new GridLayout(8, 2));

        panelCampos.add(new JLabel("ID:"));
        campoId = new JTextField();
        panelCampos.add(campoId);

        panelCampos.add(new JLabel("Apellido:"));
        campoApellido = new JTextField();
        panelCampos.add(campoApellido);

        panelCampos.add(new JLabel("Nombre:"));
        campoNombre = new JTextField();
        panelCampos.add(campoNombre);

        panelCampos.add(new JLabel("Teléfono:"));
        campoTelefono = new JTextField();
        panelCampos.add(campoTelefono);

        panelCampos.add(new JLabel("Email:"));
        campoEmail = new JTextField();
        panelCampos.add(campoEmail);

        panelCampos.add(new JLabel("Dirección:"));
        campoDireccion = new JTextField();
        panelCampos.add(campoDireccion);

        panelCampos.add(new JLabel("Fecha Inicio (dd/mm/yyyy):"));
        campoFechaInicio = new JTextField();
        panelCampos.add(campoFechaInicio);

        panelCampos.add(new JLabel("Fecha Fin (dd/mm/yyyy):"));
        campoFechaFin = new JTextField();
        panelCampos.add(campoFechaFin);

        add(panelCampos, BorderLayout.CENTER);
        
        // Panel para los botones
        JPanel panelBotones = new JPanel();
        panelBotones.setLayout(new FlowLayout());

        botonCrear = new JButton("Crear");
        panelBotones.add(botonCrear);

        botonEditar = new JButton("Editar");
        panelBotones.add(botonEditar);

        botonBorrar = new JButton("Borrar");
        panelBotones.add(botonBorrar);

        botonBuscar = new JButton("Buscar");
        panelBotones.add(botonBuscar);

        add(panelBotones, BorderLayout.SOUTH);

        // Panel para mostrar la información
        areaInformacion = new JTextArea(5, 40);
        areaInformacion.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(areaInformacion);
        add(scrollPane, BorderLayout.NORTH);
    }

    // Métodos para obtener los datos ingresados por el usuario
    public String getCampoId() {
        return campoId.getText();
    }

    public String getCampoApellido() {
        return campoApellido.getText();
    }

    public String getCampoNombre() {
        return campoNombre.getText();
    }

    public String getCampoTelefono() {
        return campoTelefono.getText();
    }

    public String getCampoEmail() {
        return campoEmail.getText();
    }

    public String getCampoDireccion() {
        return campoDireccion.getText();
    }

    public String getCampoFechaInicio() {
        return campoFechaInicio.getText();
    }

    public String getCampoFechaFin() {
        return campoFechaFin.getText();
    }

    public void setInformacion(String informacion) {
        areaInformacion.setText(informacion);
    }

    // Métodos para añadir oyentes a los botones
    public void addCrearListener(ActionListener listener) {
        botonCrear.addActionListener(listener);
    }

    public void addEditarListener(ActionListener listener) {
        botonEditar.addActionListener(listener);
    }

    public void addBorrarListener(ActionListener listener) {
        botonBorrar.addActionListener(listener);
    }

    public void addBuscarListener(ActionListener listener) {
        botonBuscar.addActionListener(listener);
    }
}

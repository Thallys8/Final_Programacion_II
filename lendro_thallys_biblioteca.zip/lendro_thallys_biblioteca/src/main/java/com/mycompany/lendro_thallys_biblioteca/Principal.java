package com.mycompany.lendro_thallys_biblioteca;

import Vista.PanelLibro;
import Vista.PanelPrestamo;
import Vista.VistaUsuarioSocioComun;
import Vista.VistaUsuarioSocioPremium;
import Controlador.ControladorLibro;
import Controlador.ControladorPrestamo;
import Controlador.ControladorUsuarioSocioComun;
import Controlador.ControladorUsuarioSocioPremium;

import javax.swing.*;

public class Principal {

    public static void main(String[] args) {
        // Configuración inicial de la interfaz gráfica (UI)
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                // Inicializar vistas
                PanelLibro vistaLibro = new PanelLibro();
                PanelPrestamo vistaPrestamo = new PanelPrestamo();
                VistaUsuarioSocioComun vistaUsuarioSocioComun = new VistaUsuarioSocioComun();
                VistaUsuarioSocioPremium vistaUsuarioSocioPremium = new VistaUsuarioSocioPremium();

                // Inicializar controladores y asociarlos a las vistas
                ControladorLibro controladorLibro = new ControladorLibro(vistaLibro);
                ControladorPrestamo controladorPrestamo = new ControladorPrestamo(vistaPrestamo);
                ControladorUsuarioSocioComun controladorUsuarioSocioComun = new ControladorUsuarioSocioComun(vistaUsuarioSocioComun);
                ControladorUsuarioSocioPremium controladorUsuarioSocioPremium = new ControladorUsuarioSocioPremium(vistaUsuarioSocioPremium);

                // Hacer visibles las vistas (puedes elegir cuál mostrar dependiendo del flujo que desees)
                vistaLibro.setVisible(true);  // Por ejemplo, mostrar la vista de libros
                vistaPrestamo.setVisible(true); // Mostrar la vista de préstamos (si lo deseas)
                vistaUsuarioSocioComun.setVisible(true);  // Mostrar la vista de Usuario Socio Común
                vistaUsuarioSocioPremium.setVisible(true);  // Mostrar la vista de Usuario Socio Premium
            }
        });
    }
}
